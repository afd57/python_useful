﻿namespace HtmlDiff
{
    public enum Mode
    {
        Character,
        Tag,
        Whitespace,
        Entity,
    }
}