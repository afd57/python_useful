﻿namespace HtmlDiff
{
    public enum Action
    {
        Equal,
        Delete,
        Insert,
        None,
        Replace
    }
}