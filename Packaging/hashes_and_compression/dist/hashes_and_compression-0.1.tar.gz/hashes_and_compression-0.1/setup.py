from distutils.core import setup

setup(
    name='hashes_and_compression',
    version='0.1',
    packages=[''],
    url='https://github.com/TheAlgorithms/Python',
    license='MIT',
    author='TheAlgorithms',
    author_email='',
    description='All algorithms implemented in Python (for education)'
)